# DengueGuard AI — Backend

## Run (≈3 min)
1. Put the full dataset CSV at `data/dengue.csv` (columns: date, city, ward_id, population_density_sqkm, water_logging_risk_index, sanitation_score, avg_temp_c, max_temp_c, min_temp_c, rainfall_mm, relative_humidity_pct, dengue_cases).
2. `pip install -r requirements.txt`
3. `uvicorn api:app --port 8000` → open http://localhost:8000 (dashboard) or /docs (API).

First start computes validation intervals + test predictions once (a few seconds) and caches them in `models/`.

## Endpoints
/meta · /cities · /heatmap · /priority · /predict (POST) · /history/{ward_id} · /performance

## AI disclosure
Claude (Anthropic) was used to help write the backend code. TODO: list every other AI assistant / API used by the team.
