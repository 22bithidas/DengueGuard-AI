"""FastAPI layer. Run:  uvicorn api:app --port 8000   (docs at /docs)"""
from contextlib import asynccontextmanager
from datetime import date as Date
from typing import List, Literal, Optional

from pathlib import Path

from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

import inference as inf


@asynccontextmanager
async def lifespan(app: FastAPI):
    inf.warmup()  # load models + build features once at startup
    yield


app = FastAPI(title="Dengue Early Warning API", version="1.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


class PredictRequest(BaseModel):
    ward_ids: List[str] = Field(min_length=1)
    date: Date
    horizon: Literal[2, 4] = 2
    rain_delta_mm: float = 0.0  # optional what-if: extra rainfall (mm) added to the latest week


def _guard(fn, *a, **kw):
    try:
        return fn(*a, **kw)
    except ValueError as e:
        raise HTTPException(400, str(e))
    except FileNotFoundError as e:
        raise HTTPException(503, f"Model or data file missing: {e}")


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/meta")
def meta():
    return _guard(inf.meta)


@app.post("/predict")
def predict(req: PredictRequest):
    return _guard(inf.predict, req.ward_ids, req.date, req.horizon, req.rain_delta_mm)


@app.get("/heatmap")
def heatmap(date: Date, horizon: int = Query(2, description="2 or 4 weeks")):
    return _guard(inf.heatmap, date, horizon)


@app.get("/priority")
def priority(date: Date, horizon: int = Query(2, description="2 or 4 weeks"), top: int = Query(10, ge=1, le=60)):
    return _guard(inf.priority, date, horizon, top)


@app.get("/cities")
def cities(date: Date, horizon: int = Query(2, description="2 or 4 weeks")):
    return _guard(inf.city_summary, date, horizon)


@app.get("/history/{ward_id}")
def history(ward_id: str, weeks: int = Query(52, ge=4, le=520), end: Optional[Date] = None):
    return _guard(inf.ward_history, ward_id, weeks, end)


@app.get("/performance")
def performance(ward_id: Optional[str] = None):
    return _guard(inf.performance, ward_id)


@app.get("/", include_in_schema=False)
def dashboard():
    return FileResponse(Path(__file__).resolve().parent / "static" / "index.html")
