# ==========================================================================
# RUN THIS AS THE LAST CELL OF THE COLAB NOTEBOOK (after STEP 18R).
# It packages the already-trained final models into the files the backend loads.
# Uses variables already in memory: final_model_2w/4w, final_preprocessor_2w/4w,
# advanced_feature_columns, val_common, test_common, train_2w_adv, final_test_predictions, df_clean.
# ==========================================================================
import platform
import joblib, sklearn, catboost, lightgbm
import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

OUT = MODEL_DIR / "backend_export"
OUT.mkdir(parents=True, exist_ok=True)

models = {2: final_model_2w, 4: final_model_4w}            # CatBoost (2w), LightGBM (4w)
preps = {2: final_preprocessor_2w, 4: final_preprocessor_4w}
targets = {2: "target_2week", 4: "target_4week"}

metrics, interval = {"validation": {}, "test": {}}, {}
for h in (2, 4):
    for split, frame in (("validation", val_common), ("test", test_common)):
        X = preps[h].transform(frame[advanced_feature_columns])
        y = frame[targets[h]].values
        p = np.maximum(models[h].predict(X), 0)
        metrics[split][str(h)] = {
            "MAE": float(mean_absolute_error(y, p)),
            "RMSE": float(np.sqrt(mean_squared_error(y, p))),
            "R2": float(r2_score(y, p)),
            "samples": int(len(y)),
            "start": str(frame["date"].min().date()),
            "end": str(frame["date"].max().date()),
        }
        if split == "validation":  # 80% empirical interval from VALIDATION residuals (no test leakage)
            resid = y - p
            interval[h] = {"lo": float(np.quantile(resid, 0.10)), "hi": float(np.quantile(resid, 0.90))}

# Risk tiers on predicted weekly cases, from the TRAINING target distribution
y_tr = train_2w_adv["target_2week"].values
tier_thresholds = {
    "medium": float(np.quantile(y_tr, 0.75)),
    "high": float(np.quantile(y_tr, 0.90)),
    "critical": float(np.quantile(y_tr, 0.97)),
}

bundle = {
    "models": models,
    "preprocessors": preps,
    "feature_cols": list(advanced_feature_columns),
    "tier_thresholds": tier_thresholds,
    "interval": interval,
    "metrics": metrics,
}
joblib.dump(bundle, OUT / "dengue_bundle.joblib", compress=3)
final_test_predictions.to_csv(OUT / "test_predictions.csv", index=False)
df_clean.to_csv(OUT / "dengue.csv", index=False)

# Exact library versions: unpickling needs the SAME versions in the backend environment
lock = [
    f"scikit-learn=={sklearn.__version__}", f"catboost=={catboost.__version__}",
    f"lightgbm=={lightgbm.__version__}", f"pandas=={pd.__version__}", f"numpy=={np.__version__}",
    f"joblib=={joblib.__version__}",
]
(OUT / "requirements.lock.txt").write_text("\n".join(lock) + "\n")

print("Tier thresholds:", tier_thresholds)
print("Interval offsets:", interval)
print("Versions (python", platform.python_version() + "):", lock)
print("Saved to:", OUT)
print("Copy dengue_bundle.joblib + test_predictions.csv -> backend/models/ ; dengue.csv -> backend/data/")
