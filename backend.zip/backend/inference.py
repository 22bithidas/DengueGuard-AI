"""Inference layer: load serialized models once, build features once, serve fast batch predictions.

Bundle contract (see CONTRACT.md / export_bundle.py):
  models        {2: CatBoost, 4: LightGBM}          fitted regressors (cases after N weeks)
  preprocessors {2: ColumnTransformer, 4: ...}      fitted on the training split only
  tier_thresholds {"medium","high","critical"}      on predicted weekly cases
  interval      {2: {"lo","hi"}, 4: {...}}          80% empirical offsets from validation residuals
  metrics       validation/test MAE, RMSE, R2
"""
from __future__ import annotations

import os
import re
from functools import lru_cache
from pathlib import Path

import joblib
import json
import numpy as np
import pandas as pd

from features import FEATURE_COLUMNS, build_features

ROOT = Path(__file__).resolve().parent
BUNDLE_PATH = Path(os.getenv("DENGUE_BUNDLE", ROOT / "models" / "dengue_bundle.joblib"))
DATA_PATH = Path(os.getenv("DENGUE_DATA", ROOT / "data" / "dengue.csv"))
TEST_PRED_PATH = Path(os.getenv("DENGUE_TEST_PRED", ROOT / "models" / "test_predictions.csv"))
HORIZONS = (2, 4)


# ---------- cached loaders: each runs ONCE per process (cost efficiency) ----------
MODEL_DIR = Path(os.getenv("DENGUE_MODEL_DIR", ROOT / "models"))
CAL_PATH = MODEL_DIR / "calibration.json"


def _split_masks(d: pd.DataFrame, h: int):
    """Same 70/15/15 chronological split with target-date purge as the notebook."""
    dates = np.sort(d["date"].unique())
    n = len(dates)
    train_end = pd.Timestamp(dates[int(n * 0.70) - 1])
    val_end = pd.Timestamp(dates[int(n * 0.85) - 1])
    tdate = d["date"] + pd.Timedelta(weeks=h)
    train = (d["date"] <= train_end) & (tdate <= train_end)
    val = (d["date"] > train_end) & (d["date"] <= val_end) & (tdate <= val_end)
    test = d["date"] > val_end
    return train, val, test


def _calibrate(models, preps) -> dict:
    """One-time: validation intervals + metrics, critical threshold, test predictions. Cached on disk."""
    from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
    f = build_features(get_raw())
    cal = {"interval": {}, "val_metrics": {}}
    tests = []
    for h in HORIZONS:
        f[f"t{h}"] = f.groupby(["city", "ward_id"])["dengue_cases"].shift(-h)
        d = f.dropna(subset=FEATURE_COLUMNS + [f"t{h}"]).reset_index(drop=True)
        tr, va, te = _split_masks(d, h)
        pred = np.clip(models[h].predict(preps[h].transform(d[FEATURE_COLUMNS])), 0, None)
        y = d[f"t{h}"].values
        r = (y - pred)[va.values]
        cal["interval"][str(h)] = {"lo": float(np.quantile(r, 0.10)), "hi": float(np.quantile(r, 0.90))}
        cal["val_metrics"][str(h)] = {
            "MAE": float(mean_absolute_error(y[va.values], pred[va.values])),
            "RMSE": float(np.sqrt(mean_squared_error(y[va.values], pred[va.values]))),
            "R2": float(r2_score(y[va.values], pred[va.values])), "samples": int(va.sum())}
        if h == 2:
            cal["critical"] = float(np.quantile(y[tr.values], 0.97))
        t = d.loc[te, ["date", "city", "ward_id"]].copy()
        t[f"actual_{h}week"] = y[te.values]
        t[f"predicted_{h}week"] = pred[te.values]
        tests.append(t)
    tp = tests[0].merge(tests[1], on=["date", "city", "ward_id"], how="inner")
    tp.to_csv(TEST_PRED_PATH, index=False)
    CAL_PATH.write_text(json.dumps(cal, indent=2))
    return cal


@lru_cache(maxsize=1)
def get_bundle() -> dict:
    if BUNDLE_PATH.exists():  # single-file bundle (export_bundle.py) still supported
        return joblib.load(BUNDLE_PATH)
    cfg = json.loads((MODEL_DIR / "feature_config.json").read_text())
    models = {2: joblib.load(MODEL_DIR / cfg["models"]["2-week"]), 4: joblib.load(MODEL_DIR / cfg["models"]["4-week"])}
    preps = {2: joblib.load(MODEL_DIR / cfg["preprocessors"]["2-week"]), 4: joblib.load(MODEL_DIR / cfg["preprocessors"]["4-week"])}
    thr = json.loads((MODEL_DIR / "risk_classification_thresholds.json").read_text())["2_week"]
    summ = json.loads((MODEL_DIR / "final_ml_project_summary.json").read_text())
    if CAL_PATH.exists() and TEST_PRED_PATH.exists():
        cal = json.loads(CAL_PATH.read_text())
    else:
        cal = _calibrate(models, preps)
    high = float(thr["high_threshold"])
    crit = max(float(cal.get("critical", 0)), high * 1.5)
    return {
        "models": models, "preprocessors": preps, "feature_cols": FEATURE_COLUMNS,
        "tier_thresholds": {"medium": float(thr["moderate_threshold"]), "high": high, "critical": crit},
        "interval": {int(k): v for k, v in cal["interval"].items()},
        "metrics": {"validation": cal["val_metrics"],
                    "test": {k[0]: v for k, v in summ["test_performance"].items()}},
    }


@lru_cache(maxsize=1)
def get_raw() -> pd.DataFrame:
    df = pd.read_csv(DATA_PATH, parse_dates=["date"])
    return df.sort_values(["city", "ward_id", "date"]).reset_index(drop=True)


@lru_cache(maxsize=1)
def get_features() -> pd.DataFrame:
    feats = build_features(get_raw()).dropna(subset=FEATURE_COLUMNS)  # only rows with full history
    return feats.set_index(["ward_id", "date"]).sort_index()


@lru_cache(maxsize=1)
def _actuals() -> pd.Series:
    return get_raw().set_index(["ward_id", "date"])["dengue_cases"]


def warmup() -> None:
    get_bundle(), get_raw(), get_features()


# ---------- helpers ----------
def tier_for(cases: float, thr: dict) -> str:
    if cases >= thr["critical"]:
        return "Critical"
    if cases >= thr["high"]:
        return "High"
    if cases >= thr["medium"]:
        return "Medium"
    return "Low"


def pretty(feature: str) -> str:
    """Human label for the UI driver chart."""
    m = re.fullmatch(r"(rainfall_mm|avg_temp_c|relative_humidity_pct)_lag_(\d+)", feature)
    names = {"rainfall_mm": "Rainfall", "avg_temp_c": "Avg temperature", "relative_humidity_pct": "Humidity"}
    if m:
        return f"{names[m.group(1)]} {m.group(2)} week(s) ago"
    m = re.fullmatch(r"dengue_lag_(\d+)", feature)
    if m:
        return f"Dengue cases {m.group(1)} week(s) ago"
    m = re.fullmatch(r"(dengue|rainfall)_roll_(\d+)", feature)
    if m:
        return f"{'Dengue cases' if m.group(1) == 'dengue' else 'Rainfall'} (prev {m.group(2)}-wk avg)"
    m = re.fullmatch(r"rainfall_sum_(\d+)w", feature)
    if m:
        return f"Rainfall (last {m.group(1)}-wk total)"
    fixed = {
        "rainfall_mm": "Rainfall (this week)", "avg_temp_c": "Avg temperature (this week)",
        "max_temp_c": "Max temperature", "min_temp_c": "Min temperature",
        "relative_humidity_pct": "Humidity (this week)", "dengue_cases": "Dengue cases (this week)",
        "population_density_sqkm": "Population density", "water_logging_risk_index": "Water-logging risk index",
        "sanitation_score": "Sanitation score", "month": "Month", "week_of_year": "Week of year",
        "week_sin": "Season (sin)", "week_cos": "Season (cos)", "ward_id": "Ward identity", "city": "City",
        "temp_humidity_interaction": "Temp x humidity", "rainfall_humidity_interaction": "Rainfall x humidity",
        "temp_rainfall_interaction": "Temp x rainfall", "temp_humidity_rainfall": "Temp x humidity x rainfall",
    }
    return fixed.get(feature, feature)


def _group_name(transformed_name: str) -> str:
    n = transformed_name.split("__", 1)[-1]
    if n.startswith("city_"):
        return "city"
    if n.startswith("ward_id_"):
        return "ward_id"
    return n


def _row(ward: str, ts: pd.Timestamp, rain_delta: float):
    """Feature row for `ward` as of the latest available week <= ts."""
    if rain_delta:
        raw = get_raw()
        sub = raw[(raw["ward_id"] == ward) & (raw["date"] <= ts)].copy()
        if sub.empty:
            raise ValueError(f"No data for {ward} on or before {ts.date()}")
        sub.iloc[-1, sub.columns.get_loc("rainfall_mm")] += rain_delta
        r = build_features(sub).iloc[-1]
        if r[FEATURE_COLUMNS].isna().any():
            raise ValueError(f"Not enough history for {ward} at {ts.date()}")
        return pd.Timestamp(sub["date"].iloc[-1]), r
    feats = get_features()
    try:
        sub = feats.loc[ward]
    except KeyError:
        raise ValueError(f"Unknown ward_id: {ward}")
    i = sub.index.searchsorted(ts, side="right") - 1
    if i < 0:
        raise ValueError(f"{ward}: date {ts.date()} is earlier than the first date with full history")
    r = sub.iloc[i].copy()
    r["ward_id"] = ward  # ward_id lives in the index of the cached table; put it back for the model
    return sub.index[i], r


def _contributions(horizon: int, Xt) -> np.ndarray:
    """Per-row additive feature contributions (SHAP) using the model's native method."""
    model = get_bundle()["models"][horizon]
    dense = Xt.toarray() if hasattr(Xt, "toarray") else np.asarray(Xt)
    if hasattr(model, "get_feature_importance"):  # CatBoost
        from catboost import Pool
        return np.asarray(model.get_feature_importance(Pool(dense), type="ShapValues"))[:, :-1]
    if model.__class__.__name__.startswith("LGBM"):  # LightGBM
        return np.asarray(model.predict(dense, pred_contrib=True))[:, :-1]
    raise TypeError("Unsupported model type for contributions")


def _drivers(horizon: int, X_raw: pd.DataFrame, Xt, top: int = 6) -> list[dict]:
    names = [_group_name(n) for n in get_bundle()["preprocessors"][horizon].get_feature_names_out()]
    contrib = _contributions(horizon, Xt)
    out = []
    for i in range(len(X_raw)):
        agg: dict[str, float] = {}
        for name, v in zip(names, contrib[i]):
            agg[name] = agg.get(name, 0.0) + float(v)  # fold one-hot columns back into city / ward_id
        best = sorted(agg.items(), key=lambda kv: abs(kv[1]), reverse=True)[:top]
        rows = []
        for feat, imp in best:
            val = X_raw.iloc[i].get(feat)
            rows.append({
                "feature": feat,
                "label": pretty(feat),
                "impact": round(imp, 4),  # + raises predicted cases, - lowers them
                "value": float(val) if isinstance(val, (int, float, np.integer, np.floating)) else None,
            })
        out.append({"method": "shap", "drivers": rows})
    return out


# ---------- public API ----------
def predict(ward_ids, date, horizon: int = 2, rain_delta_mm: float = 0.0, with_drivers: bool = True) -> list[dict]:
    """Batch prediction: ONE preprocessing + ONE model call for all requested wards."""
    b = get_bundle()
    if horizon not in b["models"]:
        raise ValueError(f"horizon must be one of {sorted(b['models'])} weeks")
    ts = pd.Timestamp(date)

    rows, meta = [], []
    for w in ward_ids:
        asof, r = _row(w, ts, rain_delta_mm)
        rows.append(r)
        meta.append((w, asof))
    X_raw = pd.DataFrame(rows)[FEATURE_COLUMNS].reset_index(drop=True)
    Xt = b["preprocessors"][horizon].transform(X_raw)
    preds = np.clip(b["models"][horizon].predict(Xt), 0, None)
    iv = b["interval"][horizon]
    drivers = _drivers(horizon, X_raw, Xt) if with_drivers else [None] * len(meta)

    actuals = _actuals()
    out = []
    for i, (w, asof) in enumerate(meta):
        p = float(preds[i])
        target_date = asof + pd.Timedelta(weeks=horizon)
        actual = actuals.get((w, target_date))
        item = {
            "ward_id": w,
            "city": str(X_raw.loc[i, "city"]),
            "as_of": asof.date().isoformat(),
            "forecast_for": target_date.date().isoformat(),
            "horizon_weeks": horizon,
            "predicted_cases": round(p, 2),
            "ci_low": round(max(0.0, p + iv["lo"]), 2),
            "ci_high": round(p + iv["hi"], 2),
            "risk_tier": tier_for(p, b["tier_thresholds"]),
            "actual_cases": None if actual is None else int(actual),  # known only for past dates
        }
        if drivers[i] is not None:
            item.update(drivers[i])
        out.append(item)
    return out


@lru_cache(maxsize=256)
def _heatmap_cached(date_iso: str, horizon: int) -> tuple:
    wards = tuple(sorted(get_raw()["ward_id"].unique()))
    return tuple(predict(wards, date_iso, horizon, with_drivers=False))


def heatmap(date, horizon: int = 2) -> list[dict]:
    return [dict(r) for r in _heatmap_cached(pd.Timestamp(date).date().isoformat(), horizon)]


def priority(date, horizon: int = 2, top: int = 10) -> list[dict]:
    rows = sorted(heatmap(date, horizon), key=lambda r: r["predicted_cases"], reverse=True)[:top]
    return [{"rank": i + 1, **r} for i, r in enumerate(rows)]


def meta() -> dict:
    raw, b, feats = get_raw(), get_bundle(), get_features()
    dates = feats.index.get_level_values("date")
    wards = raw[["ward_id", "city"]].drop_duplicates().sort_values("ward_id")
    return {
        "wards": wards.to_dict("records"),
        "cities": sorted(raw["city"].unique().tolist()),
        "date_min": dates.min().date().isoformat(),
        "date_max": raw["date"].max().date().isoformat(),
        "horizons": sorted(b["models"]),
        "tier_thresholds": b["tier_thresholds"],
        "interval_note": "80% empirical interval from validation residuals",
        "metrics": b.get("metrics", {}),
    }


def ward_history(ward: str, weeks: int = 52, end=None) -> list[dict]:
    raw = get_raw()
    sub = raw[raw["ward_id"] == ward]
    if end is not None:
        sub = sub[sub["date"] <= pd.Timestamp(end)]
    sub = sub.tail(weeks)
    if sub.empty:
        raise ValueError(f"Unknown ward_id: {ward}")
    cols = ["date", "rainfall_mm", "avg_temp_c", "relative_humidity_pct", "dengue_cases"]
    return sub[cols].assign(date=sub["date"].dt.date.astype(str)).to_dict("records")


def performance(ward: str | None = None) -> dict:
    """Actual vs predicted on the held-out TEST period (weekly totals), for the Model Performance tab."""
    get_bundle()  # makes sure the test-prediction cache exists
    df = pd.read_csv(TEST_PRED_PATH, parse_dates=["date"])
    if ward:
        df = df[df["ward_id"] == ward]
        if df.empty:
            raise ValueError(f"Unknown ward_id: {ward}")
    g = df.groupby("date")[["actual_2week", "predicted_2week", "actual_4week", "predicted_4week"]].sum().reset_index()
    g["date"] = g["date"].dt.date.astype(str)
    return {"metrics": get_bundle().get("metrics", {}), "series": g.round(2).to_dict("records")}


def city_summary(date, horizon: int = 2) -> list[dict]:
    """Per-city rainfall + predicted dengue level (avg over the city's wards)."""
    raw, r = get_raw(), pd.DataFrame(heatmap(date, horizon))
    asof = pd.Timestamp(r["as_of"].mode()[0])
    last4 = raw[(raw["date"] <= asof) & (raw["date"] > asof - pd.Timedelta(weeks=4))]
    rain4 = last4.groupby("city")["rainfall_mm"].mean()
    rain1 = raw[raw["date"] == asof].groupby("city")["rainfall_mm"].mean()
    out = []
    for c, g in r.groupby("city"):
        out.append({"city": c, "as_of": asof.date().isoformat(), "forecast_for": g["forecast_for"].iloc[0],
                    "rain_this_week_mm": round(float(rain1.get(c, 0)), 1), "rain_4wk_avg_mm": round(float(rain4.get(c, 0)), 1),
                    "avg_predicted_cases": round(float(g["predicted_cases"].mean()), 2),
                    "total_predicted_cases": round(float(g["predicted_cases"].sum()), 1),
                    "wards_by_tier": g["risk_tier"].value_counts().to_dict()})
    return out
