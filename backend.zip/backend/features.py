"""Feature engineering shared by training AND inference.

This is an exact re-implementation of the DengueGuard notebook (steps 10-18G), so the live
app computes the same lag / rolling features per ward that the models were trained on.
Everything is grouped by (city, ward_id) and uses only past + current-week information.
"""
import numpy as np
import pandas as pd

GROUP = ["city", "ward_id"]
CATEGORICAL = ["city", "ward_id"]

# 38 model inputs, same order as `advanced_feature_columns` in the notebook
FEATURE_COLUMNS = [
    "city", "ward_id", "population_density_sqkm", "water_logging_risk_index", "sanitation_score",
    "avg_temp_c", "max_temp_c", "min_temp_c", "rainfall_mm", "relative_humidity_pct", "dengue_cases",
    "dengue_lag_1", "dengue_lag_2", "dengue_lag_4", "dengue_lag_8",
    "rainfall_sum_2w", "rainfall_sum_4w",
    "avg_temp_c_lag_1", "avg_temp_c_lag_2",
    "relative_humidity_pct_lag_1", "relative_humidity_pct_lag_2",
    "rainfall_mm_lag_1", "rainfall_mm_lag_2",
    "month", "week_of_year",
    "dengue_lag_12", "dengue_lag_52",
    "dengue_roll_4", "dengue_roll_8", "dengue_roll_12",
    "week_sin", "week_cos",
    "rainfall_roll_4", "rainfall_roll_8",
    "temp_humidity_interaction", "rainfall_humidity_interaction",
    "temp_rainfall_interaction", "temp_humidity_rainfall",
]


def build_features(df: pd.DataFrame) -> pd.DataFrame:
    """Raw weekly ward data -> same rows plus all engineered features (NaN where history is too short)."""
    out = df.copy()
    out["date"] = pd.to_datetime(out["date"])
    out = out.sort_values(GROUP + ["date"]).reset_index(drop=True)

    def grp(col):
        return out.groupby(GROUP)[col]

    # dengue history
    for lag in (1, 2, 4, 8, 12, 52):
        out[f"dengue_lag_{lag}"] = grp("dengue_cases").shift(lag)

    # multi-week rainfall sums (current week included, as in training)
    for w in (2, 4):
        out[f"rainfall_sum_{w}w"] = grp("rainfall_mm").transform(
            lambda s, w=w: s.rolling(window=w, min_periods=w).sum()
        )

    # weather lags per ward
    for col in ("avg_temp_c", "relative_humidity_pct", "rainfall_mm"):
        for lag in (1, 2):
            out[f"{col}_lag_{lag}"] = grp(col).shift(lag)

    # calendar
    week = out["date"].dt.isocalendar().week.astype(int)
    out["month"] = out["date"].dt.month
    out["week_of_year"] = week
    out["week_sin"] = np.sin(2 * np.pi * week / 52.18)
    out["week_cos"] = np.cos(2 * np.pi * week / 52.18)

    # rolling means over PREVIOUS weeks (shift(1) prevents leakage)
    for w in (4, 8, 12):
        out[f"dengue_roll_{w}"] = grp("dengue_cases").transform(
            lambda s, w=w: s.shift(1).rolling(window=w, min_periods=w).mean()
        )
    for w in (4, 8):
        out[f"rainfall_roll_{w}"] = grp("rainfall_mm").transform(
            lambda s, w=w: s.shift(1).rolling(window=w, min_periods=w).mean()
        )

    # interactions
    out["temp_humidity_interaction"] = out["avg_temp_c"] * out["relative_humidity_pct"]
    out["rainfall_humidity_interaction"] = out["rainfall_mm"] * out["relative_humidity_pct"]
    out["temp_rainfall_interaction"] = out["avg_temp_c"] * out["rainfall_mm"]
    out["temp_humidity_rainfall"] = out["avg_temp_c"] * out["relative_humidity_pct"] * out["rainfall_mm"]
    return out
